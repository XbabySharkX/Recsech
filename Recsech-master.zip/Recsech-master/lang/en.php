<?php
/**
 * @Author: Nokia 1337
 * @Date:   2019-06-02 21:20:02
 * @Last Modified by:   Nokia 1337
 * @Last Modified time: 2019-06-03 04:14:53
 */
$lang['0'] = '[i] Start scanning at';
$lang['1'] = '[?] SCAN ONLY ';
$lang['2'] = "[i] Collect domain information ";
$lang['3'] = "[+] HTTP Headers for Securing :";
$lang['4'] = "[+] Inactive Domain ";
$lang['5'] = "[+] Gather information on Github ";
$lang['6'] = "Disclosure Email on Github";
$lang['7'] = "[+] Check Honeypot on all domains ";
$lang['8'] = "[+] IP Based Domain Information :";
$lang['9'] = "[+] Check Open Port (Port Scanning) ";
$lang['10'] = "[+] Domain Email";
$lang['11'] = "[+] Check Subdomain takeover ";
$lang['12'] = "[+] Check Technologies ";
$lang['13'] = "[i] Scanning is complete in {h} hour {m} minutes {s} seconds";
$lang['14'] = "[+] Check Web Application Firewalls (WAF)";
$lang['15'] = "[+] Search for all (sub) domains";